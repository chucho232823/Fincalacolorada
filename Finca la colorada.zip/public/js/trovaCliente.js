
function generateTables(container, totalTables, tablesPerColumn, numFila,zona, chairsPerTable = 4) {
    for (let col = 0; col < Math.ceil(totalTables / tablesPerColumn); col++) {
        
        // Crear un contenedor para la columna
        const column = document.createElement('div');
        column.style.display = 'grid';
        column.style.gridTemplateRows = `repeat(${tablesPerColumn}, auto)`;
        // column.style.gap = '10px';
        //column.style.gap = '0';
        if(zona === "der" || zona === "izq"){
            column.classList.add('mesasLaterales');
        }
        if(zona === "centro"){
            column.classList.add('mesasCentro');
        }

        for (let i = 0; i < tablesPerColumn; i++) {
            const tableIndex = col * tablesPerColumn + i; // Índice global de la mesa
            if (tableIndex >= totalTables) break; // No generar más mesas si excede el total

            const tableWrapper = document.createElement('div');
            tableWrapper.classList.add('table-wrapper');

            const table = document.createElement('div');
            const span = document.createElement('span');
            table.classList.add('table');
            span.classList.add('numMesa');
            table.id = (numFila++); 
            span.textContent = numFila-1;
            table.appendChild(span);
            if(zona ==='centro'){
                //primeras 3 mesas de cada fila del centro son vip
                if (i < 3) {
                    table.classList.add('vip','tres');                             
                    chairsPerTable = 3;
                    span.style.transform = 'rotate(0deg)';
                } else if( i == 3){
                    table.classList.add('preferente');
                } else {
                    table.classList.add('gral');
                    if(i == 6){
                        table.classList.add('tres');
                        chairsPerTable = 3;
                        span.style.transform = 'rotate(0deg)';
                    }
                }
                tableWrapper.appendChild(table);
            }else if(zona == 'izq'){
                //primeras 2 mesas pegadas al centro vip
                if (i < 2 && numFila > 330) {
                    table.classList.add('vip');                             
                } else if( i >= 2 && i < 4 && numFila > 330){
                    table.classList.add('preferente');
                } else if(numFila > 330){
                    table.classList.add('gral');
                } else{
                    table.classList.add('laterales');
                }
                tableWrapper.appendChild(table);
            }else if(zona == 'der'){
                //primeras 2 mesas pegadas al centro vip
                if (i < 2 && numFila < 520) {
                    table.classList.add('vip');                             
                } else if( i >= 2 && i < 4 && numFila < 520){
                    table.classList.add('preferente');
                } else if(numFila < 520){
                    table.classList.add('gral');
                } else{
                    table.classList.add('laterales');
                }
                tableWrapper.appendChild(table);
            }
            // Crear el número adecuado de sillas según 'chairsPerTable'
            for (let j = 0; j < chairsPerTable; j++) {
                const chair = document.createElement('div');   
                // console.log(table.className);
                switch(j){
                    case 0: chair.id = 'A'; 
                        break;
                    case 1: chair.id = 'B';
                        break;
                    case 2: chair.id = 'C';
                        break;
                    case 3: chair.id = 'D';
                        break;
                }                    
                if(container.className === "centro-mesas" && table.className.includes("tres")){
                    chair.classList.add('chair3');
                }else{
                    chair.classList.add('chair');
                }
                table.appendChild(chair);
            }
            chairsPerTable = 4;
            column.appendChild(tableWrapper);
            
        }
        // Agregar la columna completa al contenedor principal
        container.appendChild(column);
    }
}



function generateTablesHorizontal(container, totalTables, tablesPerRow, numFila, chairsPerTable = 3) {
    // Crear un contenedor para las filas
    const rowWrapper = document.createElement('div');
    rowWrapper.style.display = 'grid';
    rowWrapper.style.gridTemplateColumns = `repeat(${tablesPerRow}, auto)`;
    // rowWrapper.style.gap = '30px';
    rowWrapper.style.gap = '0';

    rowWrapper.classList.add('plataforma');

    for (let i = 0; i < totalTables; i++) {
        const tableIndex = i; // Índice global de la mesa

        // Si la mesa está en los índices vip, añadir la clase 'vip'
        const tableWrapper = document.createElement('div');
        tableWrapper.classList.add('table-wrapper');

        const table = document.createElement('div');
        const span = document.createElement('span');

        if(chairsPerTable == 3){
            table.classList.add('table','preferente','tres');
            span.classList.add('numMesa');
            table.id = (numFila); 
            span.textContent = numFila++;
            span.style.transform = 'rotate(0deg)'; 
            table.appendChild(span);
            tableWrapper.appendChild(table);
            // Crear el número adecuado de sillas según 'chairsPerTable'
            for (let j = 0; j < chairsPerTable; j++) {
                const chair = document.createElement('div');
                switch(j){
                    case 0: chair.id = 'A'; 
                        break;
                    case 1: chair.id = 'B';
                        break;
                    case 2: chair.id = 'C';
                        break;
                    case 3: chair.id = 'D';
                        break;
                }    
                chair.classList.add('chair3');
                table.appendChild(chair);
            }
        } else if(chairsPerTable == 2){
            table.classList.add('table','preferente','dos');
            span.classList.add('numMesa');
            table.id = (numFila); 
            span.textContent = numFila++;
            span.style.transform = 'rotate(0deg)'; 
            table.appendChild(span);
            tableWrapper.appendChild(table);

            for (let j = 0; j < chairsPerTable; j++) {
                const chair = document.createElement('div');
                switch(j){
                    case 0: chair.id = 'A'; 
                        break;
                    case 1: chair.id = 'B';
                        break;
                }    
                chair.classList.add('chair2');
                table.appendChild(chair);
            }
        }
         

        // Agregar la mesa y sus sillas a la fila
        rowWrapper.appendChild(tableWrapper);
    }

    // Agregar todas las mesas horizontales al contenedor principal
    container.appendChild(rowWrapper);
}

// Generar mesas en la sección VIP con 3 sillas por mesa

//Zona Vip naranja
//Zona Preferente blanco
//Zona General Azul

const vipContainer = document.querySelector('.centro-mesas');
generateTables(vipContainer, 7, 7, 411,"centro"); // Zona Centro fila 1
generateTables(vipContainer, 7, 7, 421,"centro"); // Zona Centro fila 2
generateTables(vipContainer, 7, 7, 431,"centro"); // Zona Centro fila 3
generateTables(vipContainer, 7, 7, 441,"centro"); // Zona Centro fila 4
generateTables(vipContainer, 7, 7, 451,"centro"); // Zona Centro fila 5
generateTables(vipContainer, 7, 7, 461,"centro"); // Zona Centro fila 6


// Generar mesas en la sección General Izquierda (tercera columna con 'vip')
const leftContainer = document.querySelector('.izq');
generateTables(leftContainer, 5, 5,311,"izq"); // La primera columna
generateTables(leftContainer, 4, 4,321,"izq"); // La segunda columna
generateTables(leftContainer, 4, 4,331,"izq"); // La tercera columna


// Generar mesas en la sección General Derecha (primera columna con 'vip')
const rightContainer = document.querySelector('.der');
generateTables(rightContainer, 5, 5,511,'der'); // La primera columna
generateTables(rightContainer, 4, 4,521,'der'); // La segunda columna
generateTables(rightContainer, 5, 5,531,'der'); // La tercera columna

// Generar mesas en las nuevas zonas del footer
const footerIzq = document.querySelector('.footer-izq');
generateTablesHorizontal(footerIzq, 2, 2, 231,2); // Mesas con 2 sillas en el footer
generateTablesHorizontal(footerIzq, 3, 3, 233,2); // Mesas con 2 sillas en el footer

const footerDer = document.querySelector('.footer-der');
generateTablesHorizontal(footerDer, 5, 5,215,2); // Mesas con 3 sillas en el footer


const sillas = document.querySelectorAll('.chair, .chair3');

/**
 * para orden del map
 */
const controlFila = new Map();
function insertSortedKey(key, value) {
  controlFila.set(key, value);

  // Ordenar por clave numérica
  const sorted = [...controlFila.entries()].sort((a, b) => a[0] - b[0]);

  // Reemplazar el contenido del map con el ordenado
  controlFila.clear();
  sorted.forEach(([k, v]) => controlFila.set(k, v));
}

/**
 * Funcion para mesas consecutivas (antierror)
 */
function conservarSoloSiConsecutivos(map) {
  const keys = [...map.keys()].sort((a, b) => a - b);

  let consecutivos = true;

  for (let i = 1; i < keys.length; i++) {
    if (keys[i] - keys[i - 1] !== 1) {
      consecutivos = false;
      //break;
    }
    if(!consecutivos){
        //console.log(`mesa: ${keys[i]} eliminada`)
        const contenedor = document.getElementById(`${keys[i]}`);
        if (contenedor) {
            // Selecciona todos los elementos hijos con la clase "activa"
            const activos = contenedor.querySelectorAll('.activa');
            // Quitar la clase "activa" a cada uno
            activos.forEach(el => el.classList.remove('activa'));
        }
    }
  }

  if (!consecutivos) {
    const firstKey = keys[0];
    const firstValue = map.get(firstKey);
    map.clear();
    map.set(firstKey, firstValue);
  }

  return map;
}

let principal;
let final;

/*sillas.forEach(silla => {
    silla.addEventListener('click', () => {
        const wrapper = silla.closest('.table-wrapper');
        const mesa = wrapper.querySelector('.table');
        if(silla.classList.contains('ocupada')){
            alert('Silla ocupada');
            return;
        }
        console.log(`Mesa: ${mesa.id} Silla: ${silla.id}`);
        if(controlFila.has(mesa.id)){
            let numero = controlFila.get(mesa.id);
            if(silla.classList.contains('activa')){
                insertSortedKey(mesa.id, --numero);
            }else{
               insertSortedKey(mesa.id, ++numero);
            }
            if(numero === 0 ){
                controlFila.delete(mesa.id);
                const [firstKey, firstValue] = controlFila?.entries?.().next?.().value ?? [];
                conservarSoloSiConsecutivos(controlFila);
                principal = firstKey;
                final = [...controlFila.entries()].at(-1);
                console.log(`Mesa inicial: ${principal} Mesa final: ${final}`);
            }
        }else if(controlFila.size == 0){
            insertSortedKey(mesa.id,1);
            const [firstKey] = controlFila?.entries?.().next?.().value ?? [];
            principal = firstKey;
            final = firstKey;
            console.log(`Mesa inicial: ${principal} Mesa final: ${final}`);
            //console.log(firstValue);
        }else{
            console.log('comprobacion:')
            console.log(`Eleccion: ${mesa.id} inicial - 1 = ${parseInt(principal) - 1} final + 1 = ${parseInt(final) + 1}`)
            if(parseInt(principal) - 1 != mesa.id && parseInt(final) + 1 != mesa.id){
                alert('esta mesa no puede ser seleccionada');
                return;
            }
            else{
                alert(`para poder apartar mas de una mesa debe sobrar
                como mucho una sola 1 silla de todas las mesas`);
                insertSortedKey(mesa.id,1);
                final = [...controlFila.entries()].at(-1);
                principal = controlFila?.entries?.().next?.().value ?? [];
            }
        }
        console.log(controlFila);
        silla.classList.toggle('activa');
    });
}); */

//probando con mesas
const mesas = document.querySelectorAll('.table');
// mesas.forEach(mesa => {
//     console.log(mesa.id);
// })

let sillasSeleccionadas = 0;
let sillasMaximas = 2;

/**
 * funcion async para verificar la silla
 */

async function verificarSilla(sembrado, mesa, silla) {
  try {
    const res = await fetch(`/estado-silla/${sembrado}?mesa=${mesa.id}&silla=${silla.id}`);

    if (!res.ok) {
      throw new Error('Error en la solicitud');
    }

    const data = await res.json();
    //console.log('Estado de la silla:', data);

    if (data[0].estado || data[0].bloqueada || data[0].enEspera) {
      silla.classList.add('ocupada');
    }

  } catch (err) {
    console.error('Error:', err);
  }
}

mesas.forEach(mesa => {
    mesa.addEventListener('click', async function(e) {
        //const wrapper = silla.closest('.table-wrapper');
        //const mesa = wrapper.querySelector('.table');
        if (e.target.classList.contains("chair") || 
              e.target.classList.contains("chair2") || 
              e.target.classList.contains("chair3")) {
    
            const silla = e.target;
            let numero = controlFila.get(mesa.id);
            await verificarSilla(sembrado, mesa, silla);
            if(silla.classList.contains('ocupada')){
                alert('Silla ocupada');
                return;
            }

            //Verificar si aun se pueden seleccionar sillas
            if(sillasSeleccionadas >= sillasMaximas && !silla.classList.contains('activa')){
                alert('Para seleccionar mas sillas aumenta el numero de boletos');
                //console.log(`Sillas seleccionadas = ${sillasSeleccionadas}`);
                // insertSortedKey(mesa.id, --numero);
                //console.log(controlFila);
                return;
            }
            // console.log(`Mesa: ${mesa.id} Silla: ${silla.id}`);

            if(controlFila.has(mesa.id)){     
                if(silla.classList.contains('activa')){
                    insertSortedKey(mesa.id, --numero);
                    sillasSeleccionadas--;
                    //console.log(`Sillas seleccionadas = ${sillasSeleccionadas}`);
                }else{
                    insertSortedKey(mesa.id, ++numero);
                }
                if(numero === 0){
                    controlFila.delete(mesa.id);
                }
            }else if(controlFila.size == 0){
                insertSortedKey(mesa.id,1);
            }else{
                //aqui se hara una desicion sobre la seleccion de mesas
                insertSortedKey(mesa.id,1);
            }
            
            if(!silla.classList.contains('activa')){
                sillasSeleccionadas++;
                //console.log(`Sillas seleccionadas = ${sillasSeleccionadas}`);
                // console.log(controlFila);
            }else{
            //    console.log(controlFila); 
            }

            silla.classList.toggle('activa');
            //console.log('hijos: ',mesa.children.length); esto se queda
            // if(numero === 2 && mesa.id >= 215 && mesa.id <= 219 && mesa.children.length === 3){
            //     const respuesta = confirm("Puedes agregar una silla mas, ¿Deseas agregarla?");
            //     if(respuesta){
            //         console.log('se agrego una silla');
            //         const chair = document.createElement('div');
            //         chair.id = 'C'
            //         chair.classList.add('chair3');
            //         mesa.appendChild(chair);
            //         // Seleccionar todos los hijos con clase "chair2 activa"
            //         const sillasL = mesa.querySelectorAll(".chair2.activa");
            //         // Recorrer y cambiar la clase
            //         sillasL.forEach((silla) => {
            //             silla.classList.remove("chair2");
            //             silla.classList.add("chair3");
            //         });
            //         // sillas = document.querySelectorAll('.chair, .chair3, .chair2');
            //     }else{
            //         //console.log('no se agrego nadota');
            //     }
            // }
            const idsValidos = new Set([
                '411', '412', '413',
                '421', '422', '423',
                '431', '432', '433',
                '441', '442', '443',
                '451', '452', '453',
                '461', '462', '463',
                '417', '427', '437',
                '447', '457', '467',
            ]);
            // if(numero === 3 && idsValidos.has(mesa.id) && mesa.children.length === 4){
            //     const respuesta = confirm("Puedes agregar una silla mas, ¿Deseas agregarla?");
            //     if(respuesta){
            //         console.log('se agrego una silla');
            //         const chair = document.createElement('div');
            //         chair.id = 'D'
            //         chair.classList.add('chair');
            //         mesa.appendChild(chair);
            //         // Seleccionar todos los hijos con clase "chair2 activa"
            //         const sillasL = mesa.querySelectorAll(".chair3.activa");
            //         // Recorrer y cambiar la clase
            //         sillasL.forEach((silla) => {
            //             silla.classList.remove("chair3");
            //             silla.classList.add("chair");
            //         });
            //         // sillas = document.querySelectorAll('.chair, .chair3, .chair2');
            //     }else{
            //         //console.log('no se agrego nadota');
            //     }
            // }
        }
        //mostrar mesas elegidas en el boletaje
        //console.log(controlFila);
        const divMesas = document.querySelector('.mesasSeleccionadas');
        
        // while (divMesas.firstChild) {
        //     divMesas.removeChild(divMesas.firstChild);
        // }
        
        //limpiando los divs
        const laterales = document.querySelector('.lateral');
        const generales = document.querySelector('.generales');
        const preferentes = document.querySelector('.preferentes');
        const vips = document.querySelector('.vips');

        laterales.style.display = 'none'
        generales.style.display = 'none'
        preferentes.style.display = 'none'
        vips.style.display = 'none'
        
        while (laterales.children.length > 1) laterales.removeChild(laterales.children[1]);
        while (generales.children.length > 1) generales.removeChild(generales.children[1]);
        while (preferentes.children.length > 1) preferentes.removeChild(preferentes.children[1]);
        while (vips.children.length > 1) vips.removeChild(vips.children[1]);

        let totalPagar = 0;
        controlFila.forEach((numero,mesa) => {
            //console.log(mesa);
            const mesaElegida = document.createElement('div');
            const sillasElegidas = document.createElement('div');
            const spanSillas = document.createElement('span');
            // const zona = document.getElementById(`${mesa}`).parentElement.parentElement.parentElement;
            const sillas = document.getElementById(`${mesa}`).children;
            //extrayendo la sona
            const zona = precios.find(b => parseInt(b.mesa) === parseInt(mesa));  
            //console.log(zona.tipo);
            // mesaElegida.innerText = `Zona ${zona.tipo} (mesa ${mesa})`;   
            spanSillas.innerHTML = `Mesa ${mesa} Silla(s) `;
            let totalMesa = 0;
            for (let i = 0; i < sillas.length; i++) {
                if(sillas[i].classList.contains('activa')){
                    const precioSilla = precios.find(b => parseInt(b.mesa) === parseInt(mesa) && b.silla === sillas[i].id)
                    //console.log(sillas[i].id);
                    //console.log(precioSilla);
                    totalMesa += precioSilla.precio;
                    spanSillas.innerHTML += `${sillas[i].id} `;
                } 
            }
            const total = document.createElement('span');
            total.innerHTML = `$${totalMesa}`;
            // sillasElegidas.append(spanSillas,total);
            mesaElegida.append(spanSillas,total);
            if(zona.tipo === "Laterales") {laterales.append(mesaElegida); laterales.style.display = 'block';};
            if(zona.tipo === "General") {generales.append(mesaElegida); generales.style.display = 'block'}
            if(zona.tipo === "Preferente") {preferentes.append(mesaElegida); preferentes.style.display = 'block'}
            if(zona.tipo === "VIP") {vips.append(mesaElegida); vips.style.display = 'block'}
            // mesaElegida.appendChild(sillasElegidas);
            // divMesas.appendChild(mesaElegida);
            totalPagar += totalMesa;
        });

        const totalPago = document.querySelector('.totalPagar > :nth-Child(2)');
        totalPago.innerHTML = `$${totalPagar}`;
        // mesaElegida.className = mesa.id;
        // mesaElegida.innerHTML = `Zona General (Mesa ${mesa.id})`;
        
        // divMesas.appendChild(mesaElegida);
    });
});

const compra = document.querySelector('.pagar');
const confirma = document.querySelector('.confirma-compra');
const fondo = document.querySelector('.fondoCompra');

//aki
let listaMesaSilla = [];
let precios = [];
let total;

/**
 * Funcion para obtener las mesas consecutivas, obviar las mesas de 2 y 3 sillas
 */

function agruparClavesConsecutivas(mapa) {
  // Obtener las claves como números y ordenarlas
  const clavesNumericas = Array.from(mapa.keys())
    .map(Number)
    .sort((a, b) => a - b);

  const secuencias = [];
  let actual = [clavesNumericas[0]];

  for (let i = 1; i < clavesNumericas.length; i++) {
    if(clavesNumericas[i] < 300){
        continue;
    }
    if (clavesNumericas[i] === clavesNumericas[i - 1] + 1) {
      actual.push(clavesNumericas[i]);
    } else {
      if (actual.length > 1) {
        secuencias.push([...actual]);
      }
      actual = [clavesNumericas[i]];
    }
  }

  // Agregar la última secuencia si aplica
  if (actual.length > 1) {
    secuencias.push([...actual]);
  }

  // Convertir los números a strings para coincidir con las claves originales
  return secuencias.map(secuencia => secuencia.map(String));
}

let consecutivas = [];
let agrupadasPorMesa = {};

/**
 * Visualizando la compra 
 */
compra.addEventListener('click', () => {
    // Obtener todas las sillas activas
    listaMesaSilla = [];
    agrupadasPorMesa = {};
    const sillasActivas = document.querySelectorAll('.chair.activa, .chair3.activa, .chair2.activa');
    total = 0;
    document.querySelector('.confirma-compra ul').innerHTML = '';
    const numSillas = controlFila.size * 4 - 1;
    
    //console.log(`Sillas minimas: ${numSillas}`);
    //console.log(`Sillas seleccionadas: ${sillasActivas.length}`);
    //verificacion de sillas seleccionadas en vertical
    //imprimir las mesas con posibles para juntar 
    //console.log(controlFila);
    consecutivas = agruparClavesConsecutivas(controlFila);
    //console.log(consecutivas);
    // if(numSillas > sillasActivas.length && controlFila.size > 1){
    //     alert(`Para apartar mas de una mesa solo tiene puede quedar una silla vacia entre todas las mesas`);
    //     return;
    // }


    if (sillasActivas.length === 0) {
        alert("No hay sillas seleccionadas!");
        return;
    }

    const lista = document.querySelector('.confirma-compra ul');
    //console.log(lista);
    const fondo = document.querySelector('.fondo-compra');
    // viendo sillas activas
    const cantidad = consecutivas.length;
    //console.log(`posibles juntadas ${cantidad}`);
    for (let i = 0; i < cantidad; i++) {
        const juntar = document.querySelector('.confirma-compra span');
        juntar.innerHTML = `Puede solicitar juntar las mesas ${consecutivas[i]} pero para ello debe comprar al menos ${consecutivas[i].length*4-1} boletos entre ambas mesas`;
    }
    //console.log('compra: ');
    sillasActivas.forEach(silla => {
        const wrapper = silla.closest('.table-wrapper');
        const mesa = wrapper.querySelector('.table');
        const idMesa = mesa.id;
        //console.log(precios);
        const precioSilla = precios.find(b => parseInt(b.mesa) === parseInt(mesa.id) && b.silla === silla.id)
        //console.log(precioSilla.precio);
        //console.log(`Mesa: ${mesa.id} Silla: ${silla.id} Precio: ${2}`);
        // Agrupar por mesa
        if (!agrupadasPorMesa[idMesa]) {
            agrupadasPorMesa[idMesa] = {
                sillas: [],
                total: 0
            };
        }

        agrupadasPorMesa[idMesa].sillas.push(silla.id);
        agrupadasPorMesa[idMesa].total += precioSilla.precio;

        total += precioSilla.precio;
        //lista.appendChild(item);
        //console.log(`Mesa: ${mesa.id} Silla: ${silla.id} Precio: ${p.precio}`);  
        const MesaSilla = {
            mesa : mesa.id,
            silla : silla.id
        }   
        listaMesaSilla.push(MesaSilla);  
    });
    //console.log(agrupadasPorMesa);
    Object.entries(agrupadasPorMesa).forEach(([mesaId, data]) => {
        const item = document.createElement('li');
        item.textContent = `Mesa ${mesaId} Silla(s): ${data.sillas.join(', ')} Total: ${data.total}`;
        lista.appendChild(item);
    });

    //confirma.appendChild(lista);
    document.querySelector('.confirma-compra h3').innerHTML = `Total a pagar: ${total}`;
    

    //confirma.appendChild(totalCompra);
    confirma.style.display = 'flex';

    fondo.style.position = 'fixed';
    document.querySelector('.main-container').style.pointerEvents = 'none';
})

//console.log('evento recibido: ', window.evento);
//console.log('id del Evento: ', window.evento.idEvento);
//nombre que se recibira 
const sembrado = window.evento.idEvento;

/**
 * Verificando el estado de la silla
 */


/*const estadoSilla = 
fetch(`/estado-sillas/${sembrado}`)
.then(response => response.json())
.then(data => {
    const lista = document.getElementById('lista-sillas');
    precios = [];
    data.forEach(item => {
        // const li = document.createElement('li');
        //console.log(`Mesa: ${item.Mesa}, Silla: ${item.Silla}, Estado: ${item.estado} Precio: ${item.precio}`);
        const precioSilla = {
            mesa: item.Mesa,
            silla: item.Silla,
            precio: item.precio,
            tipo: item.tipo
        };
        precios.push(precioSilla);
        if(item.estado || item.bloqueada || item.enEspera){
            const mesa = document.getElementById(`${item.Mesa}`);
            const table = mesa.closest('.table-wrapper');
            switch(item.Silla){
                case 'A': if(table.querySelector('#A') != null) table.querySelector('#A').classList.toggle('ocupada');
                    break;
                case 'B': if(table.querySelector('#B') != null) table.querySelector('#B').classList.toggle('ocupada');
                    break;
                case 'C': if(table.querySelector('#C') != null) table.querySelector('#C').classList.toggle('ocupada');
                    break;
                case 'D': if(table.querySelector('#D') != null) table.querySelector('#D').classList.toggle('ocupada');
                    break;
            }
        }
        // lista.appendChild(li);
    });
})
.catch(error => {
    console.error('Error al cargar datos', error);
});

// sillas ocupadas
mesas.forEach(mesa => {
    const sillas = mesa.querySelectorAll(':scope > div');
    sillas.forEach(silla =>{
        console.log(silla);
        console.log(silla.classList.contains('chair'))
        if(silla.classList.contains('ocupada'))
            console.log('ocupada');
    })
}); */

/**
 * Cargar estado de las sillas (FETCH)
 */
async function cargarEstadoSillas() {
  try {
    const response = await fetch(`/estado-sillas/${sembrado}`);
    const data = await response.json();

    precios = [];

    data.forEach(item => {
      const precioSilla = {
        mesa: item.Mesa,
        silla: item.Silla,
        precio: item.precio,
        tipo: item.tipo
      };
      precios.push(precioSilla);

      // Si la silla está ocupada / bloqueada / en espera
      if (item.estado || item.bloqueada || item.enEspera) {
        const mesa = document.getElementById(`${item.Mesa}`);
        if (!mesa) return;
        const table = mesa.closest('.table-wrapper');
        if (!table) return;
        const silla = table.querySelector(`#${item.Silla}`);
        if (silla) {
          silla.classList.add('ocupada'); // NO toggle
        }
      }
    });

  } catch (error) {
    console.error('Error al cargar datos', error);
  }
}

/**
 * Verificar sillas ocupadas (DESPUÉS del fetch)
 */
function verificarSillas() {
  mesas.forEach(mesa => {
    const sillas = mesa.querySelectorAll(':scope > div');
    let cont = 0;
    sillas.forEach(silla => {
      if (silla.classList.contains('ocupada')) {
        //console.log(`Silla ${silla.id} ocupada en mesa ${mesa.id}`);
        cont++;
      }
    });
    if(cont >= sillas.length)
        mesa.classList.add('mesaOcupada');
  });
}

/**
 * Ejecución en orden correcto
 */
(async function iniciar() {
  await cargarEstadoSillas(); // espera el fetch
  verificarSillas();          // se ejecuta después
})();

/**
 * Visualizando informacion de compra (carrito)
 * Envia los datos a al formulario para el nombre y telefono del usuario
 */
document.querySelector('.confirma-compra').addEventListener('click', function (event) {
    if (event.target.classList.contains('volver')) {
        this.style.display = 'none';
        //fondo.style.display = 'none';
        document.querySelector('.main-container').style.pointerEvents = 'all';
        document.querySelector('.fondo-compra').style.position = 'unset';
    }
    if (event.target.classList.contains('confirmar')) {
        //ir a formulario de compra para ir a metodo de pago o reservacion
        const tipo = window.evento.tipo;
        const form = document.getElementById('jsonform');
        form.action = `/datos`
        const controlFilaObjeto = Object.fromEntries(controlFila);
        //console.log(controlFilaObjeto);

        document.getElementById('jsonData').value = JSON.stringify({
            sembrado: sembrado,
            listaMesaSilla: listaMesaSilla,
            controlFila: controlFilaObjeto,
            tipo: tipo,
            consecutivas: consecutivas,
            agrupadasPorMesa: agrupadasPorMesa
        });
        //Enviar los datos
        form.submit();
        this.style.display = 'none';
        //console.log(`idEvento: ${sembrado}`);
        //console.log(listaMesaSilla);
        //console.log(controlFila);
        document.querySelector('.fondo-compra').style.position = 'unset';   
        //aqui se hace el update
        // listaMesaSilla.forEach(silla =>{
        //     reserva)rMesa(silla);
        // })
        // //fondo.style.display = 'none';
        // alert('Reservacion hecha!');
        document.querySelector('.main-container').style.pointerEvents = 'all';
        // location.reload();
    }
});

/**
 * precios
 */

fetch(`/precios/${sembrado}`)
.then(res => res.json())
.then(data => {
const tbody = document.querySelector('#tablaPrecios tbody');
data.forEach(row => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
    <td>
    <span id = 'bolita${row.tipo}'></span>
    ${row.tipo}
    </td>
    <td>$${row.precio}</td>
    `;
    tbody.appendChild(tr);
});
})
.catch(err => {
console.error('Error al cargar los precios:', err);
});

document.getElementById('inicio').addEventListener('click',(e) => {
    e.preventDefault();
    window.location.href = "/";
})
// Para control de sillas
// const allSillas = wrapper.querySelectorAll('.chair');
// allSillas.forEach(s => s.classList.remove('activa'));
// silla.classList.add('activa');

function seleccionarBoletos() {
    // 1. Obtiene el valor del campo de entrada
    const input = document.getElementById('inputBoletos');
    const laterales = document.querySelector('.lateral');
    const generales = document.querySelector('.generales');
    const preferentes = document.querySelector('.preferentes');
    const vips = document.querySelector('.vips');

    laterales.style.display = 'none'
    generales.style.display = 'none'
    preferentes.style.display = 'none'
    vips.style.display = 'none'

    document.querySelector('.totalPagar :last-child').innerHTML='$0';

    const cantidad = parseInt(input.value);
    // 2. Validación (Asegura que sea un número positivo)
    if (isNaN(cantidad) || cantidad <= 0) {
        alert("Ingresa la cantidad de boletos a comprar.");
        return; // Detiene la función si la validación falla
    }

    // 3. Guarda el valor en la variable
    sillasMaximas = cantidad;
    //console.log(`Boletos guardados: ${sillasMaximas}`);

    // Opcional: Muestra la cantidad en la página
    // document.getElementById('cantidad').textContent = sillasMaximas;

    // 4. Oculta el modal
    //document.getElementById('cantidadBoletos').style.display = 'none';

    //document.getElementById('btnReabrirModal').style.display = 'inline-block';

    mesas.forEach(mesa => {
    // Seleccionar todos los hijos de mesa que tengan la clase 'activa'
    const hijosActivos = mesa.querySelectorAll('.activa');

    // Remover la clase 'activa' de cada uno
    hijosActivos.forEach(hijo => {
        hijo.classList.remove('activa');
    });
    sillasSeleccionadas = 0;
    controlFila.clear();
    
    //Si se requieren 3 boletos activar las 3 sillas en la plataforma elevada
    if(sillasMaximas == 3){
        mesas.forEach(mesa => { 
            //aqui se usara el estado silla para verificar el estado de las sillas a anadir    
            if(mesa.id >= 215 && mesa.id <= 219 && mesa.children.length === 3){
                const chair = document.createElement('div');
                chair.id = 'C'
                chair.classList.add('chair3');
                // verificacion del estado de la silla
                fetch(`/estado-silla/${sembrado}?mesa=${mesa.id}&silla=${chair.id}`)
                .then(res => {
                    if (!res.ok) throw new Error('Error en la solicitud');
                    return res.json();
                })
                .then(data => {
                    //console.log('Estado de la silla:', data);
                    if(data[0].estado || data[0].bloqueada || data[0].enEspera)
                        chair.classList.add('ocupada');    
                })
                .catch(err => {
                    console.error('Error:', err);
                });
                mesa.appendChild(chair);
                // Seleccionar todos los hijos con clase "chair2 activa"
                const sillasL = mesa.querySelectorAll(".chair2");
                // Recorrer y cambiar la clase
                sillasL.forEach((silla) => {
                    silla.classList.remove("chair2");
                    silla.classList.add("chair3");
                });
            }
        });
    }

    if(sillasMaximas == 4){
        const idsValidos = new Set([
            '411', '412', '413',
            '421', '422', '423',
            '431', '432', '433',
            '441', '442', '443',
            '451', '452', '453',
            '461', '462', '463',
            '417', '427', '437',
            '447', '457', '467',
        ]);
        mesas.forEach(mesa => { 
            //aqui se usara el estado silla para verificar el estado de las sillas a anadir 
            // console.log(idsValidos.has(mesa.id))   
            if(idsValidos.has(mesa.id) && mesa.children.length === 4){
                const chair = document.createElement('div');
                chair.id = 'D'
                chair.classList.add('chair');
                // verificacion del estado de la silla
                fetch(`/estado-silla/${sembrado}?mesa=${mesa.id}&silla=${chair.id}`)
                .then(res => {
                    if (!res.ok) throw new Error('Error en la solicitud');
                    return res.json();
                })
                .then(data => {
                    // console.log('Estado de la silla:', data);
                    if(data[0].estado || data[0].bloqueada || data[0].enEspera)
                        chair.classList.add('ocupada');    
                })
                .catch(err => {
                    console.error('Error:', err);
                });
                mesa.appendChild(chair);
                // Seleccionar todos los hijos con clase "chair2 activa"
                const sillasL = mesa.querySelectorAll(".chair3");
                // Recorrer y cambiar la clase
                sillasL.forEach((silla) => {
                    silla.classList.remove("chair3");
                    silla.classList.add("chair");
                });
            }
        });
    }
});

}

document.getElementById('inputBoletos').addEventListener('input',seleccionarBoletos);
// Lógica para mostrar el modal inmediatamente al cargar la página (ya lo hace el HTML)
// No es necesario código adicional ya que el modal está visible por defecto.

/**
 * Reabrir modal de boletos
 */
function abrirModalBoletos() {
    // 1. Muestra el modal
    document.getElementById('cantidadBoletos').style.display = 'flex';
    mesas.forEach(mesa => {       
        if(mesa.id >= 215 && mesa.id <= 219 && mesa.querySelector('#C')){
            const chair = mesa.querySelector('#C');
            chair.remove();
            // Seleccionar todos los hijos con clase "chair2 activa"
            const sillasL = mesa.querySelectorAll(".chair3");
            // Recorrer y cambiar la clase
            sillasL.forEach((silla) => {
                silla.classList.remove("chair3");
                silla.classList.add("chair2");
            });
        }
        const idsValidos = new Set([
            '411', '412', '413',
            '421', '422', '423',
            '431', '432', '433',
            '441', '442', '443',
            '451', '452', '453',
            '461', '462', '463',
            '417', '427', '437',
            '447', '457', '467',
        ]);
        if(idsValidos.has(mesa.id) && mesa.querySelector('#D')){
            const chair = mesa.querySelector('#D');
            chair.remove();
            // Seleccionar todos los hijos con clase "chair2 activa"
            const sillasL = mesa.querySelectorAll(".chair");
            // Recorrer y cambiar la clase
            sillasL.forEach((silla) => {
                silla.classList.remove("chair");
                silla.classList.add("chair3");
            });
        }
    });
    // 2. Oculta el botón de reabrir para que no estorbe
    //document.getElementById('btnReabrirModal').style.display = 'none';
}


// para la fecha

// Extraer el día, mes y año del string de fecha
// La fecha que llega del servidor
const fechaStr = window.evento.fecha;

// Crear un array con los nombres de los meses en español (abreviados)
const meses = {
"enero": "Ene",
"febrero": "Feb",
"marzo": "Mar",
"abril": "Abr",
"mayo": "May",
"junio": "Jun",
"julio": "Jul",
"agosto": "Ago",
"septiembre": "Sep",
"octubre": "Oct",
"noviembre": "Nov",
"diciembre": "Dic"
};

const partesFecha = fechaStr.split(" de ");
const dia = partesFecha[0]; // El primer elemento es el día
const mes = meses[partesFecha[1].toLowerCase()]; // El segundo es el mes, convertimos a minúsculas para evitar errores de mayúsculas
// const anio = partesFecha[2]; // El tercer elemento sería el año (si lo necesitas, puedes usarlo también)

// Insertar los valores en el HTML
document.getElementById("mes").innerText = mes;
document.getElementById("dia").innerText = dia;