//para el swiper
const swiper = new Swiper(".mySwiper", {
    slidesPerView: 4,      // Mostrar 3 a la vez
    slidesPerGroup: 1,     // Avanzar de 1 en 1
    spaceBetween: 60,      // Separación entre items
    watchOverflow: true,
    loop: false,            // Loop infinito
    navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
    },
    breakpoints: {
        0: { slidesPerView: 1 },        // En pantallas muy pequeñas (por debajo de 400px)
        800: { slidesPerView: 2 },
        1100: { slidesPerView: 3 },
        1400: { slidesPerView: 4 }
    },
});

const hoy = new Date().toISOString().split('T')[0]; 

let datosEventos = [];
const listaEventos = 
fetch("/listado-de-eventos")
.then(response => response.json())
.then(data => {
    const eventos = document.querySelector('.principal .swiper .swiper-wrapper');
    data.forEach(evento => {
        console.log(`id: ${evento.idEvento} nombre: ${evento.nombre} tipo: ${evento.tipo} fecha: ${evento.fecha}`);
        console.log(`hora: ${evento.hora} descripcion:${evento.descripcion} imagen:${evento.imagen}`);
        console.log(`Fecha evento ${evento.fecha}`);
        console.log(`Fecha ${hoy}`);
        const ev = {
            idEvento: evento.idEvento,
            nombre: evento.nombre,
            tipo: evento.tipo,
            fecha: evento.fecha,
            hora: evento.hora,
            descripcion: evento.descripcion,
            imagen: evento.imagen
        }
        datosEventos.push(ev);

        //inicio de creacion de la tarjeta de evento
        const swiperSlide = document.createElement('div');
        swiperSlide.className = 'swiper-slide';
        const eventoDiv = document.createElement('div');
        eventoDiv.className = 'evento';

        const imagenEvento = document.createElement('img');
        imagenEvento.src = evento.imagen;
        imagenEvento.alt = "imagen evento";

        const titulo = document.createElement('span');
        titulo.className = "titulo";
        titulo.innerHTML = evento.nombre;

        const subTitulo = document.createElement('span');
        subTitulo.className = "subtitulo";
        subTitulo.innerHTML = evento.descripcion;

        const fechayHora = document.createElement('div');
        fechayHora.className = 'fechaHora';

        const fechaEvento = document.createElement('span');
        const icoFecha = document.createElement('img');
        icoFecha.className = 'ico';
        icoFecha.src = 'ico/calendario.png';
        fechaEvento.appendChild(icoFecha);
        fechaEvento.appendChild(document.createTextNode(`${evento.fecha.replace(/ de/g,'')}`));

        const horaEvento = document.createElement('span');
        const icoHora = document.createElement('img');
        icoHora.className = 'ico';
        icoHora.src = 'ico/reloj.png';
        horaEvento.appendChild(icoHora);
        horaEvento.appendChild(document.createTextNode(`   ${evento.hora}`));

        fechayHora.append(fechaEvento,horaEvento);

        const botones = document.createElement('div');
        botones.className = "botones";

        const botonVentas = document.createElement('button');
        botonVentas.textContent = 'COMPRAR BOLETOS';
        botonVentas.id = `${evento.idEvento}`;
        botonVentas.classList.add('ventas');
        botonVentas.dataset.eventoId = evento.idEvento;

        botones.append(botonVentas);

        //agregando todo al div evento
        swiperSlide.append(imagenEvento,titulo,subTitulo,fechayHora,botones)

        // eventoDiv.append(imagenEvento,titulo,subTitulo,fechayHora,botones);
        // swiperSlide.appendChild(eventoDiv);
        //agregando al swiper-wrapper correspondiente
        eventos.appendChild(swiperSlide);
        //funcion del boton Ventas
        botonVentas.addEventListener('click', (e) => {
            e.preventDefault();

            const idEvento = e.currentTarget.dataset.eventoId;

            // Buscar el objeto del evento correspondiente
            const eventoSeleccionado = datosEventos.find(ev => ev.idEvento == idEvento);

            // Preparar y enviar el formulario
            const form = document.getElementById('jsonform');
            form.action = `/sembrado/${eventoSeleccionado.tipo}Cliente`;
            document.getElementById('jsonData').value = JSON.stringify(eventoSeleccionado);
            form.submit();
        });

        // boton editar

        // Botón "Reservas"
        // const enlaceReserva = document.createElement('a');
        // enlaceReserva.textContent = 'Reservar';
        // enlaceReserva.id = `${evento.idEvento}`;
        // enlaceReserva.href = `/${(evento.tipo)}`;
        // enlaceReserva.classList.add('boton-reserva');
        // enlaceReserva.dataset.eventoId = evento.idEvento;
        
        // enlaceLista.addEventListener('click', (e) => {
        //     e.preventDefault();
        //     const idEvento = e.currentTarget.dataset.eventoId;
        //     window.location.href = `/semprado/${idEvento}`;
        // });

        // Botón "Lista"
        // const enlaceLista = document.createElement('a');
        // enlaceLista.textContent = 'Lista';
        // enlaceLista.href = '#';
        // enlaceLista.classList.add('boton-lista');
        // enlaceLista.dataset.eventoId = evento.idEvento;

        // enlaceLista.addEventListener('click', (e) => {
        //     e.preventDefault();
        //     const idEvento = e.currentTarget.dataset.eventoId;
        //     window.location.href = `/lista/${idEvento}`;
        // });

        // Botón "Editar"
        // const enlaceEditar = document.createElement('a');
        // enlaceEditar.textContent = 'Editar';
        // enlaceEditar.href = '#';
        // enlaceEditar.classList.add('boton-editar');
        // enlaceEditar.dataset.eventoId = evento.idEvento;

        //edicion que va enlazada al icono de editar/////////////////////////////////////////////////////////
        // enlaceEditar.addEventListener('click', (e) => {
        //     e.preventDefault();
        //     const idEvento = e.currentTarget.dataset.eventoId;
        //     window.location.href = `/editar/${idEvento}`;
        // });

        // Botón "Eliminar"
        // const enlaceBorrar = document.createElement('a');
        // enlaceBorrar.textContent = 'Eliminar';
        // enlaceBorrar.href = '#';
        // enlaceBorrar.classList.add('boton-borrar');
        // enlaceBorrar.dataset.eventoId = evento.idEvento;

        // enlaceBorrar.addEventListener('click', (e) => {
        //     e.preventDefault();
        //     if(!confirm("Estas seguro que deseas eliminar el evento?")){
        //         return;
        //     }
        //     const idEvento = e.currentTarget.dataset.eventoId;
        //     fetch(`/eliminar/${idEvento}`, {
        //         method: 'DELETE'
        //     })
        //     .then(response => {
        //         if (!response.ok) throw new Error('Error al eliminar');
        //         return response.json();
        //     })
        //     .then(data => {
        //         console.log(data.message);
        //         // Elimina el elemento del DOM si quieres
        //         // e.currentTarget.parentElement.remove(); (si el enlace está dentro del contenedor del evento)
        //         alert('Evento eliminado correctamente');
        //         location.reload(); // o actualiza solo esa parte del DOM
        //     })
        //     .catch(error => {
        //         console.error('Error al eliminar el evento:', error);
        //         alert('Hubo un error al eliminar el evento.');
        //     });
        // });

        // // Contenedor para botones
        // const botones = document.createElement('div');
        // botones.classList.add('botones');
        // const botonesContainer = document.createElement('div');
        // botonesContainer.classList.add('botones-container');
        // botonesContainer.appendChild(enlaceReserva);
        // botonesContainer.appendChild(enlaceLista);
        // botonesContainer.appendChild(enlaceEditar);
        // // botonesContainer.appendChild(enlaceBorrar); //fondo Rojo
        // botones.appendChild(botonesContainer);
        // botones.appendChild(enlaceBorrar);
        // // Agregamos todo al span
        // nuevoEvento.appendChild(enlace);
        // nuevoEvento.appendChild(botones);

        // eventos.appendChild(nuevoEvento);
    });
})
.catch(error => {
    console.error('Error al cargar datos', error);
});


//console.log(datosEventos);

// botonVentas.addEventListener('click', (e) => {
//     e.preventDefault();

//     const idEvento = e.currentTarget.dataset.eventoId;
//     const eventoSeleccionado = datosEventos.find(ev => ev.idEvento == idEvento);

//     // Preparas el formulario y envías
//     const form = document.getElementById('jsonform');
//     form.action = `/sembrado/${eventoSeleccionado.tipo}`;
//     document.getElementById('jsonData').value = JSON.stringify(eventoSeleccionado);
//     form.submit();
// });


// document.getElementById('Agregar').addEventListener('click', ()=> {
//     window.location.href = "Eventos.html";
// })

//Agregar Trova

//obtencion de datos
