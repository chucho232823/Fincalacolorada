const mysql = require('mysql2');

const connection = mysql.createConnection({
  host: '156.67.75.166',
  user: 'u506116281_WBVlr',
  password: 'Finca_bd.2025',
  database: 'fincalacolorada'
});

connection.connect((err) => {
  if (err) {
    console.error('Error al conectar a la base de datos:', err);
    return;
  }
  console.log('Conectado a la base de datos MySQL');
});

module.exports = connection;
