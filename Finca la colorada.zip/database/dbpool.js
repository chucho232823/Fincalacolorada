const mysql = require('mysql2/promise');

const pool = mysql.createPool({
    host: '156.67.75.166',
    user: 'u506116281_WBVlr',
    password: 'Finca_bd.2025',
    database: 'fincalacolorada'
});

module.exports = pool;