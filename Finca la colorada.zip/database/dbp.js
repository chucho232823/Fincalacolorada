const mysql = require('mysql2/promise');

async function conectar() {
  const conexion = await mysql.createConnection({
      host: '156.67.75.166',
      user: 'u506116281_WBVlr',
      password: 'Finca_bd.2025',
      database: 'fincalacolorada'
  });
  return conexion;
}

module.exports = conectar();